from django.db import models
from rest_framework import serializers


# Create your models here.
class Termek(models.Model):
    Termek_id =models.AutoField(primary_key=True)
    Termeknev= models.CharField(max_length=500)
    Ar = models.IntegerField(default=1)
    Mennyiseg = models.IntegerField(default=1)
    def __str__(self):
        return f"{self.Termeknev}"
   
class Meta:
        verbose_name_plural="Termek"

 



