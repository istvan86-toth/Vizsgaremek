from django.contrib import admin
from . models import Termek


# Register your models here.
admin.site.register(Termek)