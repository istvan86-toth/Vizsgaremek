from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpRequest
from . models import Termek


def fooldal(request):
    return render(request, 'index.html')

def termeklista(request):
    termekek=termek.objects.all()
    return render(request, 'termek.html', {"termekek": termekek})

def termekfelvitel(request):
    return render(request, 'termekekfelvitel.html')