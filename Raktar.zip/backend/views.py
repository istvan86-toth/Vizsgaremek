from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpRequest
from RaktarAPI.models import Termek


def fooldal(request):
    return render(request, 'index.html')

def termeklista(request):
    Termekek=Termek.objects.all()
    return render(request, 'termek.html', {"termekek": Termekek})

def termekfelvitel(request):
    return render(request, 'termekekfelvitel.html')